from mazegen import Wall
from mazegen.generator import MazeGenerator
from mazegen.maze import Maze
from mazegen.util import Point
from random import Random


class WilsonsGen(MazeGenerator):
    """Generate maze using loop-erased random walk (Wilson's algorithm).

    Attributes:
        maze (Maze): Maze object to be modified.
    """

    def __init__(
        self, maze: Maze,
        perfect: bool = False,
        rand: Random | float | str | None = None
    ) -> None:
        """Initialize generator.

        Args:
            maze (Maze): Object to be worked on.
            rand (Random): Random number generator.
            perfect (bool): Defines if maze should have only
                one solution (True) or more (False).
        """
        super().__init__(maze, perfect, rand)
        self._avalible = {
            Point(x, y) for x in range(maze.size.x) for y in range(maze.size.y)
        }
        self._avalible.difference_update(self.maze.pattern_cells)
        pos = self._rand.choice(list(self._avalible))
        maze.get_cell(pos).visited = True
        self._avalible.discard(pos)
        self._path: list[Point] = []

    def next(self) -> tuple[Maze, Point | None, list[Point] | None]:
        """Generate next step in maze generation.

        Returns:
            tuple[Maze, Point | None, list[Point] | None]: A tuple containing:
                - Maze: The modified maze instance.
                - Point | None: Optional coordinate of the last checked cell.
                - list[Point] | None: Optional stack of active path positions.
        """
        if not self._avalible:
            return self.maze, None, None

        if not self._path:
            self._path.append(self._rand.choice(list(self._avalible)))
            return self.maze, self._path[0], self._path.copy()

        last = self._path[-1]

        # Find valid neigbors
        neighbors: list[Point] = []
        for side in Wall.ALL:
            dx, dy = side.get_direction()
            npos = Point(last.x + dx, last.y + dy)
            if self.maze.in_bounds(npos) and not self.maze.get_cell(npos).lock:
                neighbors.append(npos)

        next = self._rand.choice(neighbors)

        # next created a loop
        if next in self._path:
            while self._path.pop() != next:
                pass
            self._path.append(next)
            return self.maze, self._path[0], self._path.copy()

        # next is previously visited path
        if self.maze.get_cell(next).visited:
            p1 = next
            while len(self._path):
                p2: Point = self._path.pop()
                dx, dy = p1.x - p2.x, p1.y - p2.y
                side = Wall.from_direction(Point(dx, dy))
                cell = self.maze.get_cell(p2)
                self.maze.try_open_wall(p2, side)
                cell.visited = True
                self._avalible.discard(p2)
                p1 = p2
            return self.maze, None, None

        self._path.append(next)
        return self.maze, self._path[0], self._path.copy()
